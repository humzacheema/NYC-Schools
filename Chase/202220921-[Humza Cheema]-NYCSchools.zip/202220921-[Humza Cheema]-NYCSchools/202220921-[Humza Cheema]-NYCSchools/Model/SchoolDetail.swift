//
//  SchoolDetail.swift
//  202220921-[Humza Cheema]-NYCSchools
//
//  Created by Humza Cheema on 9/21/22.
//

import Foundation

struct SchoolDetail:Decodable{
    var sat_math_avg_score:String
    var sat_writing_avg_score:String
    var sat_critical_reading_avg_score:String
}
