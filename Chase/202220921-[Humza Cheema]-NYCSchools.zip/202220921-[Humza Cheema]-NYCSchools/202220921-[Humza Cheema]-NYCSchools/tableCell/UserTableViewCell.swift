//
//  UserTableViewCell.swift
//  202220921-[Humza Cheema]-NYCSchools
//
//  Created by Humza Cheema on 9/21/22.
//

import UIKit

class UserTableViewCell: UITableViewCell {

    @IBOutlet weak var listOfSchools: UILabel!
    
}
